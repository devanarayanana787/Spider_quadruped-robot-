import os
import xacro
from ament_index_python.packages import get_package_share_directory

# --- CORRECTED IMPORTS ---
# LaunchDescription and conditions are top-level imports
from launch import LaunchDescription, conditions 
# OpaqueFunction, DeclareLaunchArgument, etc., are imported from launch.actions
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, OpaqueFunction 
from launch.substitutions import LaunchConfiguration, Command
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    package_name = "spider"
    robot_name = "spider"
    
    # --- Arguments ---
    world_arg = DeclareLaunchArgument('world_name', default_value='worlds/empty.world', description='World file name for Gazebo Classic')
    x_arg = DeclareLaunchArgument('x', default_value='0.0')
    y_arg = DeclareLaunchArgument('y', default_value='0.0')
    z_arg = DeclareLaunchArgument('z', default_value='0.05')
    roll_arg = DeclareLaunchArgument('R', default_value='0.0')
    pitch_arg = DeclareLaunchArgument('P', default_value='0.0')
    yaw_arg = DeclareLaunchArgument('Y', default_value='0.0')

    # --- Configurations ---
    world_name = LaunchConfiguration('world_name')
    x = LaunchConfiguration('x')
    y = LaunchConfiguration('y')
    z = LaunchConfiguration('z')
    roll = LaunchConfiguration('R')
    pitch = LaunchConfiguration('P')
    yaw = LaunchConfiguration('Y')
    
    use_sim_time_param = {'use_sim_time': True}

    # --- Paths ---
    robot_model_path = os.path.join(
        get_package_share_directory(package_name),
        'urdf',
        'spider.urdf' # Assuming this is your XACRO file
    )

    # Path to the controller configuration file (Your YAML file)
    controller_config = os.path.join(
        get_package_share_directory(package_name),
        'config',
        'spider_controller.yaml' # Your YAML file
    )

    rviz_file = os.path.join(
        get_package_share_directory(package_name),
        'config',
        'slam.rviz'
    )

    # --- Process URDF/XACRO ---
    # Processes the XACRO file to generate the final URDF string
    robot_description_content = Command(
        ['xacro ', robot_model_path, ' use_ros2_control:=true', ' robot_ip:=', 'dummy_ip']
    )
    robot_description_param = {'robot_description': robot_description_content}


    # --- Launch Descriptions & Nodes ---

    # 1. Gazebo Classic Server and Client
    gazebo_classic = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('gazebo_ros'),
                'launch',
                'gazebo.launch.py'
            )
        ),
        launch_arguments={'world': world_name}.items()
    )

    # 2. Robot State Publisher
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[robot_description_param, use_sim_time_param],
        output='screen'
    )

    # 3. Spawn Robot Entity
    spawn_model_node = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-entity', robot_name,
            '-topic', 'robot_description', 
            '-x', x, '-y', y, '-z', z,
            '-R', roll, '-P', pitch, '-Y', yaw
        ],
        output='screen'
    )
    
    # 4. Controller Manager Node 
    # This node loads the 'ros2_control' interface and the YAML parameters (often handled implicitly by Gazebo plugin, but safe to include)
    controller_manager_node = Node(
        package='controller_manager',
        executable='ros2_control_node',
        parameters=[robot_description_param, {'controller_manager.yaml': controller_config}],
        output='screen',
        remappings=[
            ('/controller_manager/robot_description', '/robot_description'),
        ],
        condition=conditions.IfCondition(LaunchConfiguration('use_sim_time')), 
    )


    # 5. Load and Start Controllers using the 'spawner' executable
    
    # Load and activate the Joint State Broadcaster
    load_joint_state_broadcaster = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '--controller-manager', '/controller_manager'],
        output='screen',
    )
    
    # Load and activate the Joint Trajectory Controller
    load_joint_trajectory_controller = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_trajectory_controller', '--controller-manager', '/controller_manager'],
        output='screen',
    )
    
    # 6. RViz
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', rviz_file],
        parameters=[use_sim_time_param],
        output='screen'
    )

    # --- Launch Description Return ---
    return LaunchDescription([
        # 1. Arguments
        world_arg, x_arg, y_arg, z_arg, roll_arg, pitch_arg, yaw_arg,

        # 2. Gazebo and core ROS nodes
        gazebo_classic,
        robot_state_publisher_node,

        # 3. Spawn the robot (Must run before controllers)
        spawn_model_node,

        # 4. Spawning the controllers
        load_joint_state_broadcaster,
        load_joint_trajectory_controller,

        # 5. Visualization
        rviz_node,
    ])
