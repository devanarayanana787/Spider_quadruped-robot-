import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration
from enum import Enum, auto

class GaitState(Enum):
    """Defines the states for the robot's automated behavior."""
    INITIALIZING = auto()
    STANDING_UP = auto()
    WAITING = auto()
    SITTING_DOWN = auto()
    SITTING = auto()

class SpiderGaitCommander(Node):
    """
    This node runs a pre-programmed sequence: stand up, wait, and then sit down.
    Angles for the poses can be configured directly in this script.
    """
    def __init__(self):
        super().__init__('spider_gait_commander')
        
        self.publisher_ = self.create_publisher(
            JointTrajectory, '/joint_trajectory_controller/joint_trajectory', 10)
        
        # ======================================================================
        # ======================= POSE CONFIGURATION =========================
        # ======================================================================
        
        self.timer_period = 0.5     # How often to check the state (in seconds)
        self.transition_time = 1.5  # seconds for stand/sit motions
        
        # -- Angles for Poses (Edit these to tune the positions) --
        femur_stance = 0
        tibia_stance = 0
        sit_femur_angle = -0.458
        sit_tibia_angle = 1.307
        
        # ======================================================================
        
        self.joint_names = [
            'f1_joint', 'f11_joint', 'f111_joint', 'f2_joint', 'f22_joint', 'f222_joint',
            'b1_joint', 'b11_joint', 'b111_joint', 'b2_joint', 'b22_joint', 'b222_joint'
        ]
        
        # --- Define Poses based on configuration angles ---
        # Poses are defined for legs with normal (_n) and inverted (_i) tibia joints
        self.POSE_STAND = {
            'L_n': [0.0, femur_stance, tibia_stance], 'R_n': [0.0, femur_stance, tibia_stance],
            'L_i': [0.0, femur_stance, -tibia_stance], 'R_i': [0.0, femur_stance, -tibia_stance]
        }
        self.POSE_SIT = {
            'L_n': [0.0, sit_femur_angle, sit_tibia_angle], 'R_n': [0.0, sit_femur_angle, sit_tibia_angle],
            'L_i': [0.0, -sit_femur_angle, -sit_tibia_angle], 'R_i': [0.0, -sit_femur_angle, sit_tibia_angle]
        }

        # Initialize state machine 
        self.current_state = GaitState.INITIALIZING
        self.last_state_change_time = self.get_clock().now()
        self.timer = self.create_timer(self.timer_period, self.gait_callback)
        self.get_logger().info('Spider Commander Initialized for Stand-Sit sequence.')

    def switch_state(self, new_state):
        """Helper function to switch states and reset timers."""
        self.current_state = new_state
        self.last_state_change_time = self.get_clock().now()
        self.get_logger().info(f"Switching to state: {new_state.name}")

    def gait_callback(self):
        """The main state machine callback, triggered by the timer."""
        elapsed_time = (self.get_clock().now() - self.last_state_change_time).nanoseconds / 1e9

        if self.current_state == GaitState.INITIALIZING:
            if elapsed_time > 1.0:
                self.get_logger().info("Commanding robot to stand...")
                self.publish_leg_poses(
                    self.POSE_STAND['L_i'], self.POSE_STAND['R_n'], 
                    self.POSE_STAND['L_n'], self.POSE_STAND['R_i'], 
                    self.transition_time)
                self.switch_state(GaitState.STANDING_UP)
            return

        elif self.current_state == GaitState.STANDING_UP:
            if elapsed_time > self.transition_time:
                self.get_logger().info("Robot is standing. Waiting for 10 seconds...")
                self.switch_state(GaitState.WAITING)
            return
            
        elif self.current_state == GaitState.WAITING:
            if elapsed_time > 10.0:
                self.get_logger().info("Wait complete. Commanding robot to sit...")
                self.publish_leg_poses(
                    self.POSE_SIT['L_i'], self.POSE_SIT['R_n'], 
                    self.POSE_SIT['L_n'], self.POSE_SIT['R_i'], 
                    self.transition_time)
                self.switch_state(GaitState.SITTING_DOWN)
            return

        elif self.current_state == GaitState.SITTING_DOWN:
            if elapsed_time > self.transition_time:
                self.get_logger().info("Sequence complete. Robot is sitting.")
                self.switch_state(GaitState.SITTING)
            return

        elif self.current_state == GaitState.SITTING:
            # Do nothing, the sequence is finished.
            pass
        
    def publish_leg_poses(self, fl_pose, fr_pose, bl_pose, br_pose, transition_time):
        """Publishes a JointTrajectory message to move the legs to the target poses."""
        traj = JointTrajectory()
        traj.joint_names = self.joint_names
        
        # Apply inversion for specific joints that are physically mirrored
        fl_pose_actual = [fl_pose[0], fl_pose[1], -fl_pose[2]] # Inverted tibia
        br_pose_actual = [br_pose[0], br_pose[1], -br_pose[2]] # Inverted tibia

        target_positions = fl_pose_actual + fr_pose + bl_pose + br_pose_actual
        
        point = JointTrajectoryPoint()
        point.positions = [float(p) for p in target_positions]
        point.time_from_start = Duration(sec=int(transition_time), nanosec=int((transition_time % 1) * 1e9))
        
        traj.points.append(point)
        self.publisher_.publish(traj)

def main(args=None):
    rclpy.init(args=args)
    gait_commander = SpiderGaitCommander()
    rclpy.spin(gait_commander)
    gait_commander.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

